export const DogcategoryList = [
    {
        title: 'Dog Food',
        productList: [
            {
                name: 'Dry Dog Food',
                key: 'DryDogFood'
            },
            {
                name: 'Wet Dog Food',
                key: 'DryDogFood'
            },
            {
                name: 'Dog Veterinary Diet',
                key: 'DryDogFood'
            },
        ]
    },
    {
        title: 'TREATS & BISCUITS',
        productList: [
            {
                name: 'Dental Treats',
                key: 'DryDogFood'
            },
            {
                name: 'Biscuits',
                key: 'DryDogFood'
            },
            {
                name: 'Jerky Treats & Chews',
                key: 'Jerky Treats & Chews'
            },
            {
                name: 'Natural Bars & Bones',
                key: 'Natural Bars & Bones'
            },
            {
                name: 'Rawhides',
                key: 'Rawhides'
            }
        ]
    },
    {
        title: 'DOG TOY',
        productList: [
            {
                name: 'Fetch Toys',
                key: 'Fetch Toys'
            },
            {
                name: 'Chew Toys',
                key: 'Chew Toys'
            },
            {
                name: 'Squeaky Toys',
                key: 'Squeaky Toys'
            },
            {
                name: 'Plush Toys',
                key: 'Plush Toys'
            },
            {
                name: 'Interactive Toys',
                key: 'Interactive Toys'
            },
            {
                name: 'Rope & Tug Toys',
                key: 'Rope & Tug Toys'
            },
        ]
    },
    {
        title: 'SUPPLIES',
        productList: [
            {
                name: 'Tick & Flea',
                key: 'Tick & Flea'
            },
            {
                name: 'Health and Wellness',
                key: 'Health and Wellness'
            },
            {
                name: 'Crates and Cages',
                key: 'Crates and Cages'
            },
            {
                name: 'Beds & Mats',
                key: 'Beds & Mats'
            },
            {
                name: 'Bandanas & Neckties',
                key: 'Bandanas & Neckties'
            },
            {
                name: 'Travel & Carriers',
                key: 'Travel & Carriers'
            },
            {
                name: 'Bowls & Feeders',
                key: 'Bowls & Feeders'
            },
            {
                name: 'Grooming',
                key: 'Grooming'
            },
            {
                name: 'Shampoos & Grooming',
                key: 'Shampoos & Grooming'
            },
            {
                name: 'Potty Training & Cleaning',
                key: 'Potty Training & Cleaning'
            },
            {
                name: 'Leashes, Collars & Harnesses',
                key: 'Leashes, Collars & Harnesses'
            }
        ]
    }
]