import React from "react";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Dashboard from '../components/Dashboard';
import AddCart from '../components/AddCart';
import Deals from '../components/Deals';
import ViewProduct from "../components/product/ViewProduct";
import Contact from "../components/Contact";
import Checkout from "../components/checkout";
import MyAccount from "../components/myAccount/MyAccount";
import AccountDashboard from "../components/myAccount/accountDashboard";
import EditAccount from "../components/myAccount/edit-account";


const Routing = () => (
  <Router>
    <Switch>
      <Route exact path='/' component={Dashboard}></Route>
      <Route exact path='/cart' component={AddCart}></Route>
      <Route exact path='/deals' component={Deals}></Route>
      <Route exact path='/product/:id' component={ViewProduct}></Route>
      <Route exact path='/contact' component={Contact}></Route>
      <Route exact path='/checkout' component={Checkout}></Route>
      <Route exact path='/my-account' component={AccountDashboard}></Route>
      <Route exact path='/my-account/edit-account' component={EditAccount}></Route>
    </Switch>
  </Router>
);

export default Routing;
