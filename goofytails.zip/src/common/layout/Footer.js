import React, { PureComponent } from 'react'
import { Input } from 'reactstrap'

export default class Footer extends PureComponent {
  render() {
    return (
      <>
        <div className="footer-top-bg w-100">
          <div className="footer-top-row">
            <div className="row">
              <div className="col-lg-2-5 col-sm-4 col-xs-12 mb-3 text-center">
                <img className="img-fluid logo" src={require('./../../assets/images/goofy-tail-logo-with-icon.png')} alt="Logo" ></img>
                <h6 style={{ paddingTop: "21px", paddingBottom: "10px" }}>Track Your order</h6>
                <Input type="text" placeholder="Tracking ID"></Input>
                <button className="track-button">Track Order</button>
              </div>

              <div className="col-lg-2-5 col-sm-4 col-xs-12 mb-3 footer-list">
                <h6>ABOUT COMPANY</h6>
                <ul className="list-remove">
                  <li><a>About Us</a></li>
                  <li><a>Retailer / Bulk Buyer</a></li>
                </ul>
              </div>

              <div className="col-lg-2-5 col-sm-4 col-xs-12 mb-3 footer-list">
                <h6>MY ACCOUNT</h6>
                <ul className="list-remove">
                  <li><a>My Account</a></li>
                  <li><a>My Cart</a></li>
                  <li><a>Order Tracking</a></li>
                </ul>
              </div>

              <div className="col-lg-2-5 col-sm-4 col-xs-12 mb-3 footer-list">
                <h6>POLICIES</h6>
                <ul className="list-remove">
                  <li><a>Privacy Policy</a></li>
                  <li><a>Cancellation Policy</a></li>
                  <li><a>Terms & Conditions</a></li>
                </ul>
              </div>

              <div className="col-lg-2-5 col-sm-4 col-xs-12 mb-3">
                <div className="subcriber-div">
                  <h6 className="subcribe-text">SUBSRIBE TO NEWSLETTER</h6>
                  <Input type="text" placeholder="Your Email"></Input>
                  <input type="submit" className="btn-subscribe" value="SUBSCRIBE" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="footer-bottom-row">
          <div className="container">
            <div className="row footer-logo-wrapper">
              <div className="col-md-6">
                <a>© All Rights Reserved. </a>
              </div>
              <div className="col-md-6 float-right">
                <img className="img-fluid w-100" src={require('./../../assets/images/footer-companies-logo.png')} alt="Logo" ></img>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}
