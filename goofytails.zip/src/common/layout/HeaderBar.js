import React, { PureComponent } from 'react';


export default class HeaderBar extends PureComponent {
    render() {
        return (
            <>
                <div className="header-bar container-fluid">
                    <div className="row main-container">
                        <div className="col-md-4 col-sm-4 pr-0 d-flex align-items-center header-contact">
                            <span className="d-flex align-items-center">
                                <i className="fa fa-envelope-open-o mr-2" aria-hidden="true"></i>
                                <a className="remove-decoration" href="mailto:care@goofytails.com?Subject=Hello%20again" target="_top">care@goofytails.com</a>
                            </span>
                            <span className="d-flex align-items-center">
                                <i className="fa fa-mobile mr-2" aria-hidden="true"></i>
                                <a href="tel:+91 9310366145" className="remove-decoration"> +91 9310366145</a>
                            </span>
                            <span className="days">We are Available 24/7</span>
                        </div>
                        <div className="col-md-4 col-sm-4">
                            <div className="offer">
                                <p className="offer-matter">
                                    <span className="get">Get 10% OFF on All Producuts Use Coupon Code</span>
                                    <span className="n10">NEW10</span>
                                </p>
                            </div>
                        </div>
                        <div className="col-md-4 col-sm-4">
                            <div className="follow">
                                <p className="mb-0">
                                    Follow us on: |
                            <a href="https://www.facebook.com/goofytails/"><i className="fa fa-facebook-square fa-facebook-square-o"> </i>
                                    </a>
                                    <a href="https://www.instagram.com/goofytailsindia/"><i className="fa fa-instagram fa-instagram-o"> </i></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}
