import React, { PureComponent } from "react";

export default class HoverMenu extends PureComponent {
    render() {
        console.log(this.props.object);
        return (
            <>
                <div className="dropdown-content">
                    <div className="row">
                        <div className="col-md-9">
                            <div className="row">
                                {
                                    this.props.object && this.props.object.map((content) =>
                                        (
                                            <div className="col-md-3 dropdown-list">
                                                <h6><a>{content.title}</a></h6>
                                                {content.productList && content.productList.map((link, index) =>
                                                    (
                                                        <a href={link.key} key={link.key}>{link.name}</a>
                                                    )
                                                )}
                                                <a className="shop-all-list">Shop all <i className="fa  fa-angle-right"></i></a>
                                            </div>
                                        )
                                    )
                                }
                                <div className="col-md-3 dropdown-list">
                                    <h6><a>Category 1</a></h6>
                                    <a href="#">Link 1</a>
                                    <a href="#">Link 2</a>
                                    <a href="#">Link 3</a>
                                    <a className="shop-all-list">Shop all <i className="fa  fa-angle-right"></i></a>
                                </div>
                                <div className="col-md-3 dropdown-list">
                                    <h6><a>Category 2</a></h6>
                                    <a href="#">Link 1</a>
                                    <a href="#">Link 2</a>
                                    <a href="#">Link 3</a>
                                    <a className="shop-all-list">Shop all <i className="fa fa-angle-right"></i></a>
                                </div>
                                <div className="col-md-3 dropdown-list">
                                    <h6><a>Category 3</a></h6>
                                    <a href="#">Link 1</a>
                                    <a href="#">Link 2</a>
                                    <a href="#">Link 3</a>
                                    <a className="shop-all-list">Shop all <i className="fa  fa-angle-right"></i></a>
                                </div>
                                <div className="col-md-3 dropdown-list">
                                    <h6><a>Category 4</a></h6>
                                    <a href="#">Link 1</a>
                                    <a href="#">Link 2</a>
                                    <a href="#">Link 3</a>
                                    <a className="shop-all-list">Shop all <i className="fa  fa-angle-right"></i></a>
                                </div>
                                <div className="col-md-12 popular-brand mt-2">
                                    <h6 className="d-flex align-items-baseline"><a className="mr-0 pl-0 pr-1" href="#">Popular Brand</a> <a className="shop-all-list pl-0">Shop all <i className="fa  fa-angle-right"></i></a></h6>
                                    <div className="row">
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                        <div className="col-md-2 pr-0">
                                            <a className="m-0 p-0"><img className="img-fluid w-100" src={require('../../assets/images/goofytails2.jpg')} alt="logo" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3 dropdown-list">
                            <img className="img-fluid w-100" src={require("../../assets/images/dog2.jpg")} alt="Img" />
                        </div>
                    </div>
                </div>
            </>
        )
    }
}