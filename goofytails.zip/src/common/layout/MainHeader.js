import React, { PureComponent } from 'react';
import { Link } from 'react-router-dom';
import { DogcategoryList } from '../../constants/menu.constant';
import HoverMenu from './HoverMenu';

export default class MainHeader extends PureComponent {
    render() {
        const categoryList = DogcategoryList;

        return (
            <>
                <div className="navbar p-0 sticky">
                    <div>
                        <ul className="d-flex justify-content-between header-list-ul">
                            <li className="dropdown">
                                <span className="dog-list d-flex justify-content-center align-items-center">
                                    <a className="ml-4">Dogs</a>
                                </span>
                                <HoverMenu object={categoryList}></HoverMenu>
                            </li>
                            <li className="dropdown">
                                <span className="cat-list d-flex justify-content-center align-items-center">
                                    <a className="ml-4">Cats</a>
                                </span>
                                <HoverMenu></HoverMenu>
                            </li>
                            <li className="dropdown">
                                <span className="small-pet-list d-flex justify-content-center align-items-center">
                                    <a className="ml-4">Small Pets</a>
                                </span>
                                <HoverMenu></HoverMenu>
                            </li>
                            <li className="dropdown">
                                <span className="goofy-box-list d-flex justify-content-center align-items-center">
                                    <a className="ml-4">Goofy Box</a>
                                </span>
                                <HoverMenu></HoverMenu>
                            </li>
                            <li className="dropdown">
                                <span className="deals-list d-flex justify-content-center align-items-center">
                                    <Link className="ml-4" to="/deals">Deals</Link>
                                </span>
                                <HoverMenu></HoverMenu>
                            </li>
                            <li className="dropdown">
                                <a className="pt-2 pl-2">Personalised</a>
                            </li>
                            <li className="dropdown">
                                <a className="pt-2 pl-2">Blog</a>
                            </li>
                            <li className="dropdown">
                                <span className="contact-list d-flex justify-content-center align-items-center">
                                    <a className="ml-4 mr-0">Contact Us</a>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </>
        )
    }
}
