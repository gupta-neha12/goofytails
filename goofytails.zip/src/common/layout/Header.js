import React, { Component } from 'react';
import { Modal, Tabs, Tab } from 'react-bootstrap';
import { Form, FormGroup, Input } from 'reactstrap';
import HeaderBar from './HeaderBar';
import MainHeader from './MainHeader';
import Login from '../../components/myAccount/login';
import Registration from '../../components/myAccount/registration';

export default class Header extends Component {
  state = {
    show: false,
    setShow: false
  };
  handleClose = () => {
    this.setState({ show: false })
  };
  handleShow = () => {
    this.setState({ show: true })
  };
  loginShow = () => {
    this.setState({ show: true })
  }

  render() {
    return (
      <>
        <div className="model-section">
          <Modal show={this.state.show} onHide={this.handleClose}>
            <Modal.Body className="p-0">
              <div className="row">
                <div className="col-lg-6 col-xs-12">
                  <img className="img-fluid w-100" src={require("../../assets/images/popup-sidebawr.jpg")} />
                </div>
                <div className="col-lg-6 col-xs-12">
                  <div className="model-right-section w-100 pr-4 pt-4">
                    <Tabs defaultActiveKey="login" id="uncontrolled-tab-example">
                      <Tab eventKey="login" title="Login">
                        <Login></Login>
                      </Tab>
                      <Tab eventKey="registration" title="SIGN UP">
                        <Registration></Registration>
                      </Tab>
                    </Tabs>
                  </div>
                </div>
              </div>
              <i className="fa fa-times-circle-o close" onClick={this.handleClose}></i>
            </Modal.Body>
          </Modal>
        </div>
        <HeaderBar />
        <div className="container-fluid margin-auto pt-2 p-0 custom-container-fluid">
          <div className="row justify-content-center align-items-center">
            <div className="col-md-4 col-sm-12 col-lg-4">
              <img className="img-fluid" src={require('../../assets/images/goofy-logo-gt.png')} />
            </div>
            <div className="col-md-4 col-sm-12 col-lg-4">
              <Form>
                <FormGroup>
                  <Input type="text" name="text" id="exampleEmail" placeholder="Search" />
                </FormGroup>
              </Form>
            </div>
            <div className="col-md-4 col-sm-12 col-lg-4 text-center">
              <div>
              </div>
              <div className="woocommerce-user-area d-lg-block d-md-block d-none">
                <ul>
                  <li className="list-remove">
                    <a href="/wishlist/" className="add-wish-list"><i className="fa fa-heart-o"> </i> <span className="your-counter-selector">0 </span>
                    </a>
                  </li>

                  <li className="list-remove">
                    <a className="add-to-cart-new" href="https://goofytails.com/cart/" title="View your shopping cart">
                      <i className="fa fa-shopping-basket"> </i> <span className="cart-contents-count"> 0 </span>
                    </a>
                  </li>

                  <li className="list-remove">
                    <a href="/my-account/" className="ml-0 cart-user-icon">
                      <img alt="User" data-cfsrc="/wp-content/uploads/2020/06/user-goofy.jpg" className="avatar avatar-80 photo avatar-default" src="https://goofytails.com/wp-content/uploads/2020/06/user-goofy.jpg" />
                      <span className="user-icon"><span className="user-name">
                      </span>
                      </span>
                    </a>
                  </li>

                  <li>
                    <a className="xoo-el-action-sc xoo-el-login-tgr" onClick={this.loginShow}>Login</a>
                  </li>

                </ul>
              </div>
            </div>
          </div>
          <hr></hr>
          <MainHeader />
        </div>
      </>
    )
  }
}
