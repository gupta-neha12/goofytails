import React, { PureComponent } from 'react'
import { Card, CardBody, CardImg, CardSubtitle, CardTitle } from 'reactstrap'

export default class ItemCard extends PureComponent {
    state= {
        source: this.props.cardItem.image,
        styles: ""
    }

    changeImage = () => {
        if(this.props.cardItem.secondImage){
            this.setState({ source: this.props.cardItem.secondImage });
        } else {
            this.setState({ styles: "change-opacity" });
        }
    }

    changeBackImage = () => {
        if(this.props.cardItem.secondImage){
            this.setState({ source: this.props.cardItem.image });
        } else {
            this.setState({ styles: "" });
        }
    }

    clickCard = () => {
        
    }

    render() {

        let sale = null;
        if(this.props.cardItem.sale)
            sale = <span className="sale-span">Sale!</span>

        let price = null;
        if(this.props.cardItem.minPrice)
            price = <span>₹ {this.props.cardItem.minPrice} - ₹ {this.props.cardItem.maxPrice}</span>;
        else if(this.props.cardItem.preciousPrice)
            price = <span><s>₹ {this.props.cardItem.preciousPrice}</s> ₹ {this.props.cardItem.price}</span>;
        else if(this.props.cardItem.price)
            price = <span>₹ {this.props.cardItem.price}</span>;

        return (
            <Card className="card-style" onClick={this.clickCard}>
                <CardImg className={this.state.styles} top width="100%" src={this.state.source} alt="Card image cap" onMouseOver={this.changeImage} onMouseLeave={this.changeBackImage} />
                <CardBody>
                    {sale}
                    <CardTitle className="card-title">{this.props.cardItem.name}</CardTitle>
                    <CardSubtitle>{price}</CardSubtitle>
                    <button className="card-button">{this.props.cardItem.button}</button>
                </CardBody>
            </Card>
        )
    }
}
