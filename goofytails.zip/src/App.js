import React from 'react';
import './App.scss';
import Header from './common/layout/Header';
import Footer from './common/layout/Footer';
import Routing from './routes/Routing';

function App() {
  return (
    <div >
      <Header />
      <Routing></Routing>
      <Footer />
    </div>
  );
}

export default App;
