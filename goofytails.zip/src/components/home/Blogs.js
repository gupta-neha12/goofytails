import React, { Component, PureComponent } from 'react'
import { Card, CardBody, CardImg, CardTitle } from 'reactstrap'

export default class Blogs extends PureComponent {
  state = {
    blogList: [
      {
        id: 1,
        image: require('./../../assets/images/dummy/blogs-image.png'),
        name: 'DOGA - A YOGA WITH DOGGOS'
      },
      {
        id: 2,
        image: require('./../../assets/images/dummy/blogs-image.png'),
        name: 'DOGA - A YOGA WITH DOGGOS'
      },
      {
        id: 3,
        image: require('./../../assets/images/dummy/blogs-image.png'),
        name: 'DOGA - A YOGA WITH DOGGOS'
      },
      {
        id: 4,
        image: require('./../../assets/images/dummy/blogs-image.png'),
        name: 'DOGA - A YOGA WITH DOGGOS'
      }
    ]
  }

  render() {
    this.blogView = [];
    this.state.blogList.forEach((element) => {
      this.blogView.push(
        <SingleCard cardItem={element} key={element.id}></SingleCard>
      );
    })

    return (
      <>
        <div className="blog-div">
          <h2 className="blog-text">Blogs</h2>
          <div className="row">
            {this.blogView}
          </div>
          <button className="read-more-button">Read More</button>
        </div>
      </>
    )
  }
}

class SingleCard extends Component {
  render() {
    return (
      <div className="col-md-3">
        <Card>
          <CardImg top width="100%" src={this.props.cardItem.image} alt="Card image cap" />
          <CardBody>
            <CardTitle className="blog-title">{this.props.cardItem.name}</CardTitle>
          </CardBody>
        </Card>
      </div>
    );
  }
}