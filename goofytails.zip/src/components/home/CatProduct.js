import React, { PureComponent } from 'react'
import ItemCard from '../../common/element/ItemCard';

export default class CatProduct extends PureComponent {
  state = {
    catProduct: [
      {
        id: 1,
        image: require('./../../assets/images/dummy/cat-prod-dummy-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'ADD TO CART',
        sale: true
      },
      {
        id: 2,
        image: require('./../../assets/images/dummy/cat-prod-dummy-image.png'),
        secondImage: require('./../../assets/images/dummy/cat-product-dummy-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        minPrice: 350.00,
        maxPrice: 550.00,
        button: 'VIEW PRODUCT'
      },
      {
        id: 3,
        image: require('./../../assets/images/dummy/cat-prod-dummy-image.png'),
        secondImage: require('./../../assets/images/dummy/cat-product-dummy-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        preciousPrice: 375.00,
        button: 'ADD TO CART'
      }
    ]
  }

  render() {
    this.productView = [];
    this.state.catProduct.forEach((element) => {
      this.productView.push(
        <div className="col-md-4" key={element.id}>
          <ItemCard cardItem={element}></ItemCard>
        </div>
      );
    })

    return (
      <>
        <div className="cat-product-row">
          <div className="row">
            <div className="col-lg-5 col-sm-12 col-xs-12 mb-2">
              <img className="img-fluid cat-image" src={require('./../../assets/images/cat-product-image.png')} alt="Logo" ></img>
            </div>
            <div className="col-lg-7 col-sm-12 col-xs-12">
              <div className="row">{this.productView}</div>
            </div>
          </div>
        </div>
      </>
    )
  }
}