import React, { PureComponent } from 'react'
import ItemCard from '../../common/element/ItemCard';

export default class GoofyChewers extends PureComponent {
  state = {
    productList: [
      {
        id: 1,
        image: require('./../../assets/images/dummy/addition-image.png'),
        secondImage: require('./../../assets/images/dummy/second-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'VIEW PRODUCT',
        sale: true
      },
      {
        id: 2,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'ADD TO CART',
        sale: true
      },
      {
        id: 3,
        image: require('./../../assets/images/dummy/addition-image.png'),
        secondImage: require('./../../assets/images/dummy/second-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        minPrice: 350.00,
        maxPrice: 550.00,
        button: 'ADD TO CART'
      },
      {
        id: 4,
        image: require('./../../assets/images/dummy/addition-image.png'),
        secondImage: require('./../../assets/images/dummy/second-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'VIEW PRODUCT',
        sale: true
      },
      {
        id: 5,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'ADD TO CART',
        sale: true
      },
      {
        id: 6,
        image: require('./../../assets/images/dummy/addition-image.png'),
        secondImage: require('./../../assets/images/dummy/second-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        preciousPrice: 375.00,
        button: 'ADD TO CART'
      }
    ]
  }

  render() {
    this.productView = [];
    this.state.productList.forEach((element) => {
      this.productView.push(
        <div className="col-lg-2 col-sm-4 col-xs-12" key={element.id}>
          <ItemCard cardItem={element}></ItemCard>
        </div>
      );
    })

    return (
      <>
        <div className="new-product-div">
          <h2 className="new-product-text">Goofy Chewers</h2>
          <div className="row">
            {this.productView}
          </div>
        </div>
      </>
    )
  }
}