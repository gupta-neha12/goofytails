import React, { PureComponent } from 'react'
import ItemCard from '../../common/element/ItemCard';

export default class BestSeller extends PureComponent {
  state = {
    productList: [
      {
        id: 1,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'VIEW PRODUCT',
        sale: true
      },
      {
        id: 2,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'ADD TO CART',
        sale: true
      },
      {
        id: 3,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        minPrice: 350.00,
        maxPrice: 550.00,
        button: 'ADD TO CART'
      },
      {
        id: 4,
        image: require('./../../assets/images/dummy/addition-image.png'),
        name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
        price: 350.00,
        button: 'VIEW PRODUCT',
        sale: true
      }
    ]
  }

  render() {
    this.productView = [];
    this.state.productList.forEach((element) => {
      this.productView.push(
        <div className="col-lg-6 col-sm-6 col-xs-12 pb-3" key={element.id}>
          <ItemCard cardItem={element}></ItemCard>
        </div>
      );
    })

    return (
      <>
        <div className="product-box">
          <div className="product-box-inner px-2">
            <h2 className="border-title">BEST SELLERS</h2>
            <div className="row">
              {this.productView}
            </div>
          </div>
        </div>
      </>
    )
  }
}