import React, { PureComponent } from 'react';

export default class DiscountCover extends PureComponent {
  render() {
    return (
      <div className="container-fluid goofy_coupon mob pb-5">
        <div className="row">
          <div className="col-md-6 col-sm-6">
            <a >
              <img className="img-fluid no-lazy" src={require('./../../assets/images/dog-cover-discount.png')} alt="dog deal cover"/>
            </a>
          </div>
          <div className="col-md-6 col-sm-6">
            <a >
              <img className="img-fluid no-lazy" src={require('./../../assets/images/cat-cover-discount.png')} alt="cat deal cover"/>
            </a>
          </div>
        </div>
      </div>
    );
  }
}