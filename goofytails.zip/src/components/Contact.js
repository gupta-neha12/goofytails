import React, { Component } from 'react';
import { Form, FormGroup, Input, Card, CardBody, CardTitle, CardSubtitle, CardText } from 'reactstrap';
import MapView from './MapView';

export default class Contact extends Component {
    static defaultProps = {
        center: {
            lat: 59.95,
            lng: 30.33
        },
        zoom: 10
    };

    render() {
        return (
            <div className="container contact-container">
                <div className="text-center">
                    <h3>Contact Us</h3>
                </div>
                <div className="row">
                    <div className="col-md-4">
                        <Card style={{ backgroundColor: '#f8f9f9' }}>
                            <CardBody>
                                <div className="text-center">
                                    <h5 className="header-contact">Our Location</h5>
                                    <h6>Goofy Tails Pvt Ltd</h6>
                                    <p className="contact-pargraph">A-89, DDA Sheds, Okhla Industrial Area Phase 2 ,</p>
                                    <p className="contact-pargraph">South Delhi,</p>
                                    <p className="contact-pargraph">Delhi-110020</p>
                                </div>
                            </CardBody>
                        </Card>
                    </div>
                    <div className="col-md-4">
                        <Card style={{ backgroundColor: '#f8f9f9' }}>
                            <CardBody>
                                <div className="text-center">
                                    <h5 className="header-contact">Contact us Anytime</h5>
                                    <p className="mb-1">
                                        <i className="mr-2" className="fa fa-whatsapp b-icon"></i>
                                        <a href="https://wa.me/919310366145?text=Hi,%20can%20you%20help%20me%20this%20Products?" className="contact-link" >+91 9310366145</a>
                                    </p>
                                    <p>
                                        <i className="fa fa-phone b-icon"></i>
                                        <a className="contact-link" href="tel:+919310366145">+91 9310366145</a>
                                    </p>
                                </div>
                            </CardBody>
                        </Card>
                    </div>
                    <div className="col-md-4">
                        <Card style={{ backgroundColor: '#f8f9f9' }}>
                            <CardBody>
                                <div className="text-center">
                                    <h5 className="header-contact">Write Some Words</h5>
                                    <p>
                                        <i className="fa fa-envelope b-icon"></i>
                                        <a className="contact-link" href="mailto:care@goofytails.com"> care@goofytails.com</a>
                                    </p>
                                    <p className="pt-0"><b>Operating Hours :</b> 10AM – 6PM</p>
                                </div>
                            </CardBody>
                        </Card>
                    </div>
                </div>

                <div className="row contact-details">
                    <div className="col-md-6">
                        <Form>
                            <FormGroup>
                                <Input type="text" name="name" id="name" placeholder="Your Name" />
                            </FormGroup>
                            <FormGroup>
                                <Input type="email" name="email" id="email" placeholder="Your Email" />
                            </FormGroup>
                            <FormGroup>
                                <Input type="number" name="number" id="number" placeholder="Your Number" />
                            </FormGroup>

                            <FormGroup>
                                <Input type="textarea" name="text" id="details" style={{ height: '100px' }} placeholder="More Details about your pet, budget etc." />
                            </FormGroup>
                            <button className="submit-contact-button">SUBMIT</button>
                        </Form>
                    </div>

                    <div className="col-md-6">
                        <MapView />
                    </div>

                </div>

            </div>
        )
    }
}
