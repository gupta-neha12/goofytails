import React, { PureComponent } from "react";
import { Accordion, Button, Card } from "react-bootstrap";

export default class Checkout extends PureComponent {
    render() {
        return (
            <>
                <section className="checkout-section mt-4">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 mb-3">
                                <div className="checkout-title">
                                    <h1 className="w-50">You are one step away from a healthy life!</h1>
                                </div>
                            </div>
                            <div className="col-lg-7 col-sm-12 col-xs-12">
                                <div className="information-section">
                                    <h3>Information</h3>
                                    <div className="form-section">
                                        <form>
                                            <Accordion>
                                                <p>Already have an account with us? <span>
                                                    <Accordion.Toggle as={Button} variant="link" eventKey="0">Log in for a faster checkout experience.
                                                </Accordion.Toggle>
                                                </span></p>
                                                <div className="form-group text-left">
                                                    <label htmlFor="exampleInputEmail1">Email address</label>
                                                    <input type="email"
                                                        className="form-control"
                                                        id="email"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Enter email"
                                                    />
                                                    <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
                                                </div>
                                                <Accordion.Collapse eventKey="0">
                                                    <div className="form-group text-left">
                                                        <label htmlFor="exampleInputPassword1">Password</label>
                                                        <input type="password"
                                                            className="form-control"
                                                            id="password"
                                                            placeholder="Password"
                                                        />
                                                        <button
                                                            type="submit" className="btn-login">
                                                            Login
                                                        </button>
                                                    </div>

                                                </Accordion.Collapse>
                                            </Accordion>
                                            <div className="row m-0">
                                                <h3 className="w-100">Shipping address</h3>
                                                <div className="form-group text-left pl-0 col-lg-6 col-sm-12 col-xs-12">
                                                    <label htmlFor="exampleInputPassword1">First Name</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="firstName"
                                                        placeholder="First Name"
                                                    />
                                                </div>
                                                <div className="form-group text-left pr-0 col-lg-6 col-sm-12 col-xs-12">
                                                    <label htmlFor="exampleInputPassword1">Last Name</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="lastName"
                                                        placeholder="Last Name"
                                                    />
                                                </div>
                                                <div className="form-group text-left col-lg-12 p-0">
                                                    <label htmlFor="exampleInputPassword1">Street Address</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="streetAddress"
                                                        placeholder="Street Address"
                                                    />
                                                </div>
                                                <div className="form-group text-left pl-0 col-lg-4 col-sm-12 col-xs-12">
                                                    <label htmlFor="exampleInputPassword1">Country / Region</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="lastName"
                                                        placeholder="Last Name"
                                                    />
                                                </div>
                                                <div className="form-group text-left pl-0 pr-0 col-lg-4 col-sm-12 col-xs-12">
                                                    <label htmlFor="exampleInputPassword1">Postcode / ZIP</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="lastName"
                                                        placeholder="Last Name"
                                                    />
                                                </div>
                                                <div className="form-group text-left pr-0 col-lg-4 col-sm-12 col-xs-12">
                                                    <label htmlFor="exampleInputPassword1">State</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="lastName"
                                                        placeholder="Last Name"
                                                    />
                                                </div>
                                                <div className="form-group text-left col-lg-12 p-0">
                                                    <label htmlFor="exampleInputPassword1">Town / City</label>
                                                    <input type="text"
                                                        className="form-control"
                                                        id="city"
                                                        placeholder="Town / City"
                                                    />
                                                </div>
                                                <div className="form-group text-left col-lg-12 p-0">
                                                    <label htmlFor="exampleInputPassword1">Phone</label>
                                                    <input type="number"
                                                        className="form-control"
                                                        id="phone"
                                                        placeholder="Phone"
                                                    />
                                                </div>
                                                <h3 className="w-100">Payments</h3>
                                                <h3 className="w-100">Billing Address</h3>
                                                <div className="form-group text-left col-lg-12 p-0">
                                                    <Accordion>
                                                        <Card>
                                                            <Card.Header>
                                                                <Accordion.Toggle eventKey="0">
                                                                    <input type="radio"
                                                                        className="mr-3"
                                                                        id="billingAdress"
                                                                        name="billingAddress"
                                                                    />Same as Shipping address
                                                                </Accordion.Toggle>
                                                            </Card.Header>
                                                        </Card>
                                                        <Card>
                                                            <Card.Header>
                                                                <Accordion.Toggle eventKey="1">
                                                                    <input type="radio"
                                                                        className="mr-3"
                                                                        id="billingAdress"
                                                                        name="billingAddress"
                                                                    />Use a different billing address
                                                                </Accordion.Toggle>
                                                            </Card.Header>
                                                            <Accordion.Collapse eventKey="1">
                                                                <Card.Body>
                                                                    <div className="row m-0">
                                                                        <div className="form-group text-left pl-0 col-lg-6 col-sm-12 col-xs-12">
                                                                            <label htmlFor="exampleInputPassword1">First Name</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="firstName"
                                                                                placeholder="First Name"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left pr-0 col-lg-6 col-sm-12 col-xs-12">
                                                                            <label htmlFor="exampleInputPassword1">Last Name</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="lastName"
                                                                                placeholder="Last Name"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left col-lg-12 p-0">
                                                                            <label htmlFor="exampleInputPassword1">Street Address</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="streetAddress"
                                                                                placeholder="Street Address"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left pl-0 col-lg-4 col-sm-12 col-xs-12">
                                                                            <label htmlFor="exampleInputPassword1">Country / Region</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="lastName"
                                                                                placeholder="Last Name"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left pl-0 pr-0 col-lg-4 col-sm-12 col-xs-12">
                                                                            <label htmlFor="exampleInputPassword1">Postcode / ZIP</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="lastName"
                                                                                placeholder="Last Name"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left pr-0 col-lg-4 col-sm-12 col-xs-12">
                                                                            <label htmlFor="exampleInputPassword1">State</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="lastName"
                                                                                placeholder="Last Name"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left col-lg-12 p-0">
                                                                            <label htmlFor="exampleInputPassword1">Town / City</label>
                                                                            <input type="text"
                                                                                className="form-control"
                                                                                id="city"
                                                                                placeholder="Town / City"
                                                                            />
                                                                        </div>
                                                                        <div className="form-group text-left col-lg-12 p-0">
                                                                            <label htmlFor="exampleInputPassword1">Phone</label>
                                                                            <input type="number"
                                                                                className="form-control"
                                                                                id="phone"
                                                                                placeholder="Phone"
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </Card.Body>
                                                            </Accordion.Collapse>
                                                        </Card>
                                                    </Accordion>
                                                </div>
                                                <div className="row align-items-center m-0 order-btn-section w-100 mt-4 mb-4">
                                                    <div className="col-lg-6 col-sm-6 col-xs-12 pl-0">
                                                        <a className="btn-return-cart">Return To Cart</a>
                                                    </div>
                                                    <div className="col-lg-6 col-sm-6 col-xs-12 text-right pr-0">
                                                        <a className="btn-com-order">COMPLETE ORDER</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-5 col-sm-12 col-xs-12 border-left">
                                <div className="totle-price-section position-sticky">
                                    <div className="row m-0">
                                        <div className="col-lg-12 item-section">
                                            <div className="row m-0 align-items-center">
                                                <div className="col-lg-3 position-relative">
                                                    <img className="img-fluid" src={require("../assets/images/cart.jpg")} />
                                                    <span className="count">1</span>
                                                </div>
                                                <div className="col-lg-6">
                                                    <div className="item-name-section">
                                                        <h6>Dog Toys</h6>
                                                        <span className="ml-4">Dog Toys × 1</span>
                                                    </div>
                                                </div>
                                                <div className="col-lg-3">
                                                    <p className="text-right">Subtotal:<br></br>
                                                    <span><em>₹</em>350</span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="col-lg-12">
                                                <div className="promo-code d-flex align-items-center w-100 mt-5 mb-5">
                                                    <input type="text" placeholder="Enter Promo Code"/>
                                                    <a>Apply</a>
                                                </div>
                                            </div>
                                            <div className="col-lg-12">
                                                <div className="sub-total-section mt-3 mb-5">
                                                    <div className="total-price d-flex align-items-center mb-1 pb-1 w-100">
                                                        <span>
                                                            Subtotal
                                                        </span>
                                                        <span className="text-right">
                                                            <em>₹</em>350
                                                        </span>
                                                    </div>
                                                    <div className="total-price d-flex align-items-center mb-1 pb-1 w-100 weight-600">
                                                        <span>
                                                            Total
                                                        </span>
                                                        <span className="text-right">
                                                            <em>₹</em>350
                                                        </span>
                                                    </div>
                                                    <div className="special-notes">
                                                        <span className="float-right mt-2">
                                                        (includes <em>₹</em><em>76</em> VAT)
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}
