import React, { PureComponent } from "react";
import { Tabs, Tab } from "react-bootstrap";
import Registration from "./registration";
import Login from "./login";

export default class MyAccount extends PureComponent {
    render() {
        return (
            <>
                <section className="login-registration-section">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="login-registration-inner">
                                    <Tabs defaultActiveKey="login" id="uncontrolled-tab-example">
                                        <Tab eventKey="login" title="Login">
                                            <Login></Login>
                                        </Tab>
                                        <Tab eventKey="registration" title="SIGN UP">
                                            <Registration></Registration>
                                        </Tab>
                                    </Tabs>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}
