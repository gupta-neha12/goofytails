import React, { PureComponent, Component } from "react";

export default class EditAccount extends PureComponent {
    render() {
        return (
            <>
                <section className="account-dashboard-section mt-3 mb-3">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-3 col-sm-3 col-xs-12">
                                <UserDashboardSidebar></UserDashboardSidebar>
                            </div>
                            <div className="col-lg-9 col-sm-9 col-xs-12">
                                <div className="dashboard-content">
                                    <div className="input-area mb-4">
                                        <p>First Name<span>*</span></p>
                                        <input type="text" placeholder="First Name" />
                                    </div>
                                    <div className="input-area mb-4">
                                        <p>Last Name<span>*</span></p>
                                        <input type="text" placeholder="Last Name" />
                                    </div>
                                    <div className="input-area mb-4">
                                        <p>Display Name<span>*</span></p>
                                        <input type="text" placeholder="Display Name" />
                                        <em className="notes-show">This will be how your name will be displayed in the account section and in reviews</em>
                                    </div>
                                    <div className="input-area mb-4">
                                        <p>Email Address<span>*</span></p>
                                        <input type="text" placeholder="Email Address" />
                                    </div>
                                    <h6 className="mb-3">Password Change</h6>
                                    <div className="input-area mb-4">
                                        <p>Current Password (leave blank to leave unchanged)</p>
                                        <input type="text" placeholder="Current Password" />
                                    </div>
                                    <div className="input-area mb-4">
                                        <p>New Password (leave blank to leave unchanged)</p>
                                        <input type="text" placeholder="New Password" />
                                    </div>
                                    <div className="input-area mb-4">
                                        <p>Confirm New Password</p>
                                        <input type="text" placeholder="Confirm New Password" />
                                    </div>
                                    <button className="save-changes-btn">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}

export class UserDashboardSidebar extends Component {
    render() {
        return (
            <>
                <div className="user-sidebar-section">
                    <ul className="list-unstyled">
                        <li><a className="active">Dashboard</a></li>
                        <li><a>Orders</a></li>
                        <li><a>Downloads</a></li>
                        <li><a>Addresses</a></li>
                        <li><a>Account Details</a></li>
                        <li><a>Logout</a></li>
                    </ul>
                </div>
            </>
        )
    }
}
