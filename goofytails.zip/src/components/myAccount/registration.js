import React, { PureComponent } from "react";

export default class Registration extends PureComponent {
    render() {
        return (
            <>
                <form className="xoo-el-action-form mt-3 mb-3">
                    <div className="xoo-aff-group">
                        <div className="xoo-aff-input-group d-flex align-items-center">
                            <span className="xoo-aff-input-icon fa fa-at"></span>
                            <input className="text-password-type" type="text" placeholder="Email" />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-6 col-sm-6 col-xs-6">
                            <div className="xoo-aff-group">
                                <div className="xoo-aff-input-group d-flex align-items-center">
                                    <span className="xoo-aff-input-icon fa fa-user"></span>
                                    <input className="text-password-type" type="text" placeholder="First Name" />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 col-sm-6 col-xs-6">
                            <div className="xoo-aff-group">
                                <div className="xoo-aff-input-group d-flex align-items-center">
                                    <span className="xoo-aff-input-icon fa fa-user"></span>
                                    <input className="text-password-type" type="text" placeholder="Last Name" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="xoo-aff-group">
                        <div className="xoo-aff-input-group d-flex align-items-center">
                            <span className="xoo-aff-input-icon fa fa-key"></span>
                            <input className="text-password-type" type="password" placeholder="Password" />
                        </div>
                    </div>
                    <div className="xoo-aff-group">
                        <div className="xoo-aff-input-group d-flex align-items-center">
                            <span className="xoo-aff-input-icon fa fa-key"></span>
                            <input className="text-password-type" type="password" placeholder="Confirm Password" />
                        </div>
                    </div>
                    <div className="xoo-aff-group border-0">
                        <label className="xoo-el-form-label">
                            <input type="checkbox" name="xoo-el-rememberme" value="forever" />
                            <span className="ml-2">I accept the <a>Terms of Service and Privacy Policy</a></span>
                        </label>
                    </div>
                    <button type="submit" className="xoo-el-action-btn xoo-el-login-btn">SIGN UP</button>
                </form>
            </>
        )
    }
}
