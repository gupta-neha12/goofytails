import React, { PureComponent } from "react";

export default class Login extends PureComponent {
    render() {
        return (
            <>
                <form className="xoo-el-action-form mt-3 mb-3">
                    <div className="xoo-aff-group">
                        <div className="xoo-aff-input-group d-flex align-items-center">
                            <span className="xoo-aff-input-icon fa fa-user"></span>
                            <input className="text-password-type" type="text" placeholder="Username / Email" />
                        </div>
                    </div>
                    <div className="xoo-aff-group">
                        <div className="xoo-aff-input-group d-flex align-items-center">
                            <span className="xoo-aff-input-icon fa fa-key"></span>
                            <input className="text-password-type" type="password" placeholder="Password" />
                        </div>
                    </div>
                    <div className="xoo-aff-group border-0">
                        <label className="xoo-el-form-label">
                            <input type="checkbox" name="xoo-el-rememberme" value="forever" />
                            <span className="ml-2">Remember me</span>
                        </label>
                        <a className="xoo-el-lostpw-tgr float-right">Forgot Password?</a>
                    </div>
                    <button type="submit" className="xoo-el-action-btn xoo-el-login-btn">SIGN IN</button>
                    <div className="sociallogin pt-2 text-center">
                        <h5 className="pb-2">Login with</h5>
                        <div>
                            <div className="the_champ_login_container">
                                <ul className="the_champ_login_ul d-inline-flex">
                                    <li>
                                        <i className="fa fa-facebook" alt="Login with Facebook" title="Login with Facebook">
                                        </i>
                                    </li>
                                    <li>
                                        <i className="fa fa-google" alt="Login with Google" title="Login with Google" >
                                        </i>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </form>
            </>
        )
    }
}
