import React, { PureComponent, Component } from "react";

export default class AccountDashboard extends PureComponent {
    render() {
        return (
            <>
                <section className="account-dashboard-section mt-3 mb-3">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-3 col-sm-3 col-xs-12">
                                <UserDashboardSidebar></UserDashboardSidebar>
                            </div>
                            <div className="col-lg-9 col-sm-9 col-xs-12">
                                <div className="dashboard-content">
                                    <p>
                                        Hello <span>digvijay singh.shekhawat</span> (not <span>digvijay singh.shekhawat?</span> <a>Log out</a>)
                                    </p>
                                    <p>
                                        From your account dashboard you can view your <a>recent orders</a>,  manage your <a>shipping and billing addresses</a>, and <a>edit your password and account details</a>.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}

export class UserDashboardSidebar extends Component {
    render() {
        return (
            <>
                <div className="user-sidebar-section">
                    <ul className="list-unstyled">
                        <li><a className="active">Dashboard</a></li>
                        <li><a>Orders</a></li>
                        <li><a>Downloads</a></li>
                        <li><a>Addresses</a></li>
                        <li><a>Account Details</a></li>
                        <li><a>Logout</a></li>
                    </ul>
                </div>
            </>
        )
    }
}
