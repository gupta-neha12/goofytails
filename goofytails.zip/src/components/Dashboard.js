import React, { Component, PureComponent } from 'react'
import BestSeller from './home/BestSeller';
import Blogs from './home/Blogs'
import CatProduct from './home/CatProduct';
import DiscountCover from './home/DiscountCover';
import FeaturedItems from './home/FeaturedItems';
import GoofyBox from './home/GoofyBox';
import GoofyCatToys from './home/GoofyCatToys';
import GoofyChewers from './home/GoofyChewers';
import GoofyPlushies from './home/GoofyPlushies';
import NewAddition from './home/NewAddition';

export default class Dashboard extends PureComponent {
  state = {
  }

  render() {
    return (
      <>
        <div>
          <a ><img className="img-fluid" src={require("../assets/images/home-main.png")} /></a>
        </div>
        <ThreeSection></ThreeSection>
        <GoofyPlushies></GoofyPlushies>
        <GoofyBox></GoofyBox>
        <GoofyChewers></GoofyChewers>
        <DiscountCover></DiscountCover>
        <GoofyCatToys></GoofyCatToys>
        <VideoContent></VideoContent>
        <CatProduct></CatProduct>
        <NewAddition></NewAddition>
        <Blogs></Blogs>
      </>
    )
  }
}

class ThreeSection extends Component {
  render() {
    return (
      <section className="Second-section">
        <div className="container-fluid mt-5 mb-5">
          <div className="row">
            <div className="col-lg-4 col-sm-12 col-xs-12">
              <FeaturedItems></FeaturedItems>
            </div>
            <div className="col-lg-4 col-sm-12 col-xs-12">
              <div className="cover-bg d-md-block d-none p-4">
                <img className="img-fluid" src={require('./../assets/images/home-goofy-box-text.png')} />
                <p>Curated Toys, Treats and Supplies<br />Hamper Customised for your Pet.</p>
                <a> ORDER NOW</a>
              </div>
            </div>
            <div className="col-lg-4 col-sm-12 col-xs-12">
              <BestSeller></BestSeller>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

class VideoContent extends Component {
  render() {
    return (
      <div className="container-fluid px-0">
        <div className="row cover-video">
          <div className="text-center mb-5">
            <a >
              <img className="img-fluid" src={require('./../assets/images/play-icon-gt.png')} />
            </a>
            <h2 className="text-white">Goofy Tails Himalayan Yak Milk Bars 100% Natural Dog treat</h2>
          </div>
        </div>
      </div>
    );
  }
}
