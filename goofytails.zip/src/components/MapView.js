import { Map, InfoWindow, Marker, GoogleApiWrapper } from 'google-maps-react';
import React, { Component } from 'react';

const mapKey ="AIzaSyC3teiR65c8QwwH9rFA1xMnYBQNDQ8W7oQ";
const mapStyles = {
    width: '100%',
    height: '100%'
};

export class MapView extends Component {

    state = {
        showingInfoWindow: true,
        activeMarker: {},
        selectedPlace: {},
    };

    onMarkerClick = (props, marker, e) =>
        this.setState({
            selectedPlace: props,
            activeMarker: marker,
            showingInfoWindow: true
        });

    onMapClicked = (props) => {
        if (this.state.showingInfoWindow) {
            this.setState({
                showingInfoWindow: true,
                activeMarker: null
            })
        }
    };
    componentDidMount() {

    }
    render() {
        return (
            <Map
                bootstrapURLKeys={{ apiKey: "AIzaSyC3teiR65c8QwwH9rFA1xMnYBQNDQ8W7oQ" }}
                google={this.props.google}
                shadow={'none'}
                onClick={this.onMapClicked}
                style={mapStyles}
                zoom={14}
                initialCenter={
                    {
                        lat: 28.531500,
                        lng: 77.272099
                    }
                }
            >
                <Marker onClick={this.onMarkerClick}
                    name={'Goofy Tails Pet Shop |The Com...'}
                    adrees={'A-89, Okhla Phase II, DDA Shed, Block A, Okhla Phase II, Okhla Industrial Area, New Delhi, Delhi 11002'}
                />

                <InfoWindow
                    onCloseClick={() => {
                        this.setState({})
                    }}
                    position={{
                        lat: 28.531500,
                        lng: 77.272099
                    }}
                    marker={this.state.activeMarker}
                    visible={this.state.showingInfoWindow}

                >
                    <div style={{ width: '250px' }}>
                        <h6>{this.state.selectedPlace.name}</h6>
                        <span>{this.state.selectedPlace.adrees}</span><br></br>
                        <a jstcache="44" href="http://www.google.co.in/search?q=Goofy+Tails+Pet+Shop+%7CThe+Complete+Pet+Product+Store,+A-89,+Okhla+Phase+II,+DDA+Shed,+Block+A,+Okhla+Phase+II,+Okhla+Industrial+Area,+New+Delhi,+Delhi+110020&amp;ludocid=8813501716599241116#lrd=0x390cfb5500283e5d:0x7a4fd91d8531799c,1" jsaction="mouseup:placeCard.reviews" class="review-box-link" jsan="7.review-box-link,8.href,0.target,22.jsaction">44 reviews</a>
                        <br></br>
                        <a jstcache="46" href="https://maps.google.com/maps?ll=28.531189,77.272228&amp;z=16&amp;t=m&amp;hl=en&amp;gl=IN&amp;mapclient=embed&amp;cid=8813501716599241116" jsaction="mouseup:placeCard.largerMap">View larger map</a>
                    </div>


                </InfoWindow>
            </Map>
        )
    }
}

export default GoogleApiWrapper({
    apiKey: mapKey
})(MapView)