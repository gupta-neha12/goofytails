import React, { Component, PureComponent } from 'react'
import product from '../../api/product';
import DiscountCover from '../home/DiscountCover';
import ItemCard from '../../common/element/ItemCard';
import productList from '../../api/product-list';
import ProductImage from './ProductImage';
import ProductDetail from './ProductDetail';

export default class ViewProduct extends PureComponent {
    state = {
        productId: this.props.match.params.id,
        product: product()
    }

    render() {
        return (
            <section className="container-fluid mx-5">
                <section className="row mb-3">
                    <div className="col-lg-5 col-sm-12 col-xs-12 pl-0 mt-3">
                        <ProductImage image={this.state.product.image} imageList={this.state.product.images}></ProductImage>
                    </div>
                    <div className="col-lg-7 col-sm-12 col-xs-12 pr-0 mt-3">
                        <ProductDetail product={this.state.product}></ProductDetail>
                    </div>
                </section>
                <div className="row mb-3 d-flex justify-content-center">
                    <h2 className="my-2">Related Products</h2>
                    <RelatedProduct></RelatedProduct>
                </div>
                <div className="row mb-3">
                    <DiscountCover></DiscountCover>
                </div>
            </section>
        )
    }
}

class RelatedProduct extends Component {
    state = {
        productList: productList(4)
    }

    render() {
        this.productView = [];
        this.state.productList.forEach((element) => {
            this.productView.push(
                <div className="col-md-3" key={element.id}>
                    <ItemCard cardItem={element}></ItemCard>
                </div>
            );
        })
        return (
            <>
                <div className="row m-2">
                    {this.productView}
                </div>
            </>
        );
    }
}