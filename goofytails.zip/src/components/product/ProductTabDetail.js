import React, { Component, PureComponent } from 'react'
import { Tab, TabList, TabPanel, Tabs } from 'react-tabs'

export default class ProductTabDetail extends PureComponent {
    state = {
        additionalInfo: this.props.additionalInfo,
        description: this.props.description
    }

    render() {

        return (
            <section className="container-fluid p-0">
                <Tabs className="react-tabs" defaultIndex={0}>
                    <TabList>
                        <Tab>Description</Tab>
                        <Tab>Additional information</Tab>
                        <Tab>Reviews</Tab>
                    </TabList>
                    <TabPanel>
                        {this.state.description}
                    </TabPanel>
                    <TabPanel>
                        {this.state.additionalInfo.map(element => {
                            return (
                                <div className="row py-2" key={element.key}>
                                    <span className="col-lg-2 info-title">{element.key}</span>
                                    <span className="col-lg-10">{element.value}</span>
                                </div>
                            );
                        })}
                    </TabPanel>
                    <TabPanel>
                        <NoReviews></NoReviews>
                    </TabPanel>
                </Tabs>
            </section>
        )
    }
}

class NoReviews extends Component {
    render() {
        return (
            <>
                <div className="review">
                    <div className="no-review">
                        <span>There are no reviews yet.</span>
                    </div>
                    <span>Be the first to review “Arden Grange Puppy Junior Chicken and Rice Dog Food”</span>
                    <div className="d-flex justify-content-center">
                        <div>
                            <span>Login with your Social ID</span>
                            <div className="d-block d-flex justify-content-center">
                                <a><i className="fa fa-facebook-f fa-2x"></i></a>
                                <a><i className="fa fa-google fa-2x"></i></a>
                            </div>
                        </div>
                    </div>

                    <p>
                        <span>Your email address will not be published. Required fields are marked</span>
                        <span className="required">*</span>
                    </p>

                    <div className="comment-form-rating">
                        <label htmlFor="rating">Your rating</label>
                        <select name="rating" id="rating" required>
                            <option value="">Rate…</option>
                            <option value="5">Perfect</option>
                            <option value="4">Good</option>
                            <option value="3">Average</option>
                            <option value="2">Not that bad</option>
                            <option value="1">Very poor</option>
                        </select>
                    </div>

                    <p className="comment-form-comment">
                        <label htmlFor="comment">Your review <span className="required">*</span></label>
                        <textarea className="w-100" id="comment" name="comment" rows="8" required></textarea>
                    </p>

                    <p className="comment-form-author">
                        <label htmlFor="author">Name <span className="required">*</span></label>
                        <input className="review__input" id="author" name="author" type="text" required />
                    </p>

                    <p className="comment-form-email">
                        <label htmlFor="email">Email <span className="required">*</span></label>
                        <input className="review__input" id="email" name="email" type="email" required />
                    </p>

                    <p className="form-submit">
                        <input className="comment-button" name="submit" type="submit" value="Submit" />
                    </p>
                </div>
            </>
        );
    }
}
