import React, { Component, PureComponent } from 'react'
import ReactTooltip from 'react-tooltip'
import ProductTabDetail from './ProductTabDetail'

export default class ProductDetail extends PureComponent {
    state = {
        product: this.props.product,
        quantity: this.props.product.quantity,
        pincode: this.props.product.pincode,
        icon: "fa fa-heart-o"
    }

    setFavorite = () => {
        if(this.state.icon =="fa fa-heart-o")
            this.setState({ icon: "fa fa-heart"})
        else
            this.setState({ icon: "fa fa-heart-o"})
    }

    render() {
        return (
            <section className="container-fluid product-detail-div">
                <div className="d-flex justify-content-between">
                    <h5 className="text-c-primary">{this.state.product.name}</h5>
                    <i className={this.state.icon + " fa-2x text-c-secondary"} onClick={this.setFavorite}></i>
                </div>
                <div>
                    <ul>
                        {this.state.product.description.map((element) => <li key={element}>{element}</li>)}
                    </ul>
                </div>
                <div className="row my-3">
                    <span className="col-lg-2 text-c-primary font-weight-bold">Price:</span>
                    <span className="col">From: <span className="price">₹ {this.state.product.price}</span></span>
                </div>
                <div className="row my-3">
                    <span className="col-lg-2 text-c-primary font-weight-bold">Stock:</span>
                    <span className="col text-c-secondary">{this.state.product.stock}</span>
                </div>
                <div className="row my-3">
                    <span className="col-lg-2 text-c-primary font-weight-bold py-1">Quantity:</span>
                    <div className="col">
                        <input className="input-text-box p-1"
                            type="number"
                            value={this.state.quantity}
                            onChange={(event) => this.setState({ quantity: event.target.value })} />
                    </div>
                </div>
                <div className="row my-3">
                    <span className="col-lg-2 text-c-primary font-weight-bold py-2">Pin Code:</span>
                    <div className="col d-inline pin-code-div">
                        <input className="pin-code-input p-2"
                            type="number"
                            placeholder="Enter Pincode"
                            value={this.state.pincode}
                            onChange={(event) => { this.setState({ pincode: event.target.value }) }} />
                        <button className="pin-code-button py-2 px-3">Check Availability</button>
                    </div>
                </div>
                {this.props.product.weight ? <Weight weight={this.props.product.weight}></Weight> : null}
                {(this.state.product.stock == 'Out OF Stock') ? <Alert></Alert> : null}
                <ProductTabDetail additionalInfo={this.state.product.additionalInfo} description={this.state.product.descriptionBlock}></ProductTabDetail>
            </section>
        )
    }
}

class Weight extends Component {
    render() {
        return (
            <>
                <span className="row my-3 pl-4">Select variation to check availability!</span>
                <div className="row my-3">
                    <span className="col-lg-2 text-c-primary font-weight-bold">Weight:</span>
                    <div className="col d-inline">
                        {
                            this.props.weight.map(elem => {
                                return (
                                    <div key={elem} className="d-inline">
                                        <span data-tip={elem + " kg"} id={"Tooltip-" + elem} className="weight-span p-1 m-2">{elem} kg</span>
                                        <ReactTooltip type="dark" place="top" effect="solid" />
                                    </div>
                                );
                            })
                        }
                    </div>
                </div>
            </>
        );
    }
}

class Alert extends Component {
    state = {
        email: ""
    }
    render() {
        return (
            <>
                <div className="my-5">
                    <span>Notify me ! When this product is available.</span>
                    <input className="alert-input p-2"
                        type="text"
                        placeholder="Enter your email"
                        value={this.state.email}
                        onChange={(event) => this.setState({ email: event.target.value })} />
                    <button className="alert-button px-4 py-2 my-2">GET AN ALERT</button>
                </div>
            </>
        );
    }
}