import React, { PureComponent } from 'react'

export default class ProductImage extends PureComponent {
    state = {
        image: this.props.image,
        images: this.props.imageList
    }

    render() {
        this.imageView = [];
        this.state.images.forEach((element, index) => {
            this.imageView.push(
                <li key={index} className="m-1 border list-remove">
                    <img onClick={() => this.setState({ image: element })}
                        className="img-fluid image-list"
                        src={element} alt="product list view" />
                </li>
            );
        })

        return (
            <section className="container-fluid product-image">
                <div className="row mb-3">
                    <div className="col-lg-2 col-sm-12 col-xs-12 px-0 image-panel">
                        <ol className="p-0 image-container">
                            {this.imageView}
                        </ol>
                    </div>
                    <div className="col-lg-10 col-sm-12 col-xs-12 py-2 border">
                        <img className="img-fluid flex-viewport" src={this.state.image} alt="product main pic" />
                    </div>
                </div>
                <div className="row button-group">
                    <div className="col-lg-12 col-sm-12 col-xs-12 p-0 d-flex justify-content-center">
                        <button className="prod-button-1 py-2">ADD TO CART</button>
                        <button className="prod-button-2 py-2">BUY NOW</button>
                    </div>
                </div>
            </section>
        )
    }
}