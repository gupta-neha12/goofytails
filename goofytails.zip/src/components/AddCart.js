import React, { PureComponent } from 'react'

export default class AddCart extends PureComponent {
    render() {
        return (
            <section className="card-page mt-5">
                <div className="container">
                    <div className="row product-wrapper">
                        <div className="col-md-12">
                            <div className="message">
                                <p>Cart Updated</p>
                            </div>
                        </div>
                        <div className="col-lg-8 col-sm-6 col-xs-12">
                            <h6 className="heading6 mb-4">MY CART(1)</h6>
                            <div className="item-detail">
                                <div className="row ml-0 mr-0">
                                    <div className="col-lg-3 col-sm-12 col-xs-12 img-section text-center">
                                        <a><img className="p-2 mb-1 img-fluid w-100" src={require('../assets/images/cart.jpg')} alt="logo" /></a>
                                        <div className="d-flex align-items-center mb-2">
                                            <span>
                                                Quantity
                                            </span>
                                            <input className="w-100" type="number" />
                                        </div>
                                    </div>
                                    <div className="col-lg-9 col-sm-12 col-xs-12 detail-section pt-2 pb-2">
                                        <h5>Basil Daily Wipes for Dogs and Cats 80 pcs</h5>
                                        <p className="mb-0 price-tag">
                                            <span>Price: </span><em>₹</em>
                                            350
                                        </p>
                                        <p className="mb-0 price-tag">
                                            <span>Sub Total: </span><em>₹</em>
                                            350
                                        </p>
                                        <div className="btn-section">
                                            <a className="hover-black">Save For Later</a>
                                            <a className="hover-pink">Remove</a>
                                        </div>
                                    </div>
                                </div>
                                <a className="update-cart-btn">Update Cart</a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 col-xs-12 border-left mb-3">
                            <h6 className="heading6 mb-4">PRICE DETAILS</h6>
                            <div className="price-section">
                                <div className="d-flex">
                                    <p className="price-item w-50">PRICE
                                        <span>(1) ITEMS</span>
                                    </p>
                                    <p className="item-cost w-50">
                                        <em>₹</em>350
                                    </p>
                                </div>
                                <div className="d-flex">
                                    <p className="price-item w-50">Shipping</p>
                                    <p className="item-cost w-50">
                                        <span className="note-for-cost w-100">Order less than 500 INR would be extra chargeable with flat rate of 50 INR.:</span>
                                        <em>₹</em>50

                                        <span className="shipping-location mt-3 w-100 d-block">Shipping to <span>Delhi</span>.</span>
                                    </p>
                                </div>
                                <div className="d-flex">
                                    <p className="price-item w-50">TOTAL PAYABLE</p>
                                    <p className="item-cost w-50">
                                        <em>₹</em>400
                                    </p>
                                </div>
                            </div>
                            <a className="place-order-btn">PLACE ORDER</a>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}
