import React, { PureComponent } from 'react'
import { Link } from 'react-router-dom';
import ItemCard from '../common/element/ItemCard';

export default class Deals extends PureComponent {
    state = {
        dogProduct: [
            {
                id: 1,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'VIEW PRODUCT',
                sale: true
            },
            {
                id: 2,
                image: require('./../assets/images/dummy/addition-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'ADD TO CART',
                sale: true
            },
            {
                id: 3,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                minPrice: 350.00,
                maxPrice: 550.00,
                button: 'ADD TO CART'
            },
            {
                id: 4,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'VIEW PRODUCT',
                sale: true
            },
            {
                id: 5,
                image: require('./../assets/images/dummy/addition-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'ADD TO CART',
                sale: true
            },
            {
                id: 6,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                preciousPrice: 375.00,
                button: 'ADD TO CART'
            }
        ],
        catProduct: [
            {
                id: 1,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'VIEW PRODUCT',
                sale: true
            },
            {
                id: 2,
                image: require('./../assets/images/dummy/addition-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'ADD TO CART',
                sale: true
            },
            {
                id: 3,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                minPrice: 350.00,
                maxPrice: 550.00,
                button: 'ADD TO CART'
            },
            {
                id: 4,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'VIEW PRODUCT',
                sale: true
            },
            {
                id: 5,
                image: require('./../assets/images/dummy/addition-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                button: 'ADD TO CART',
                sale: true
            },
            {
                id: 6,
                image: require('./../assets/images/dummy/addition-image.png'),
                secondImage: require('./../assets/images/dummy/second-image.png'),
                name: 'Goofy Tails Puppy Teething Chew Toy Ball & Bone Combo (Blue/Pink) for Medium & Large Dogs',
                price: 350.00,
                preciousPrice: 375.00,
                button: 'ADD TO CART'
            }
        ]
    }

    render() {

        this.dogView = [];
        this.state.dogProduct.forEach(element => {
            this.dogView.push(
                <div className="col-md-3 mb-3" key={element.id}>
                    <ItemCard cardItem={element}></ItemCard>
                </div>
            );
        })

        this.catView = [];
        this.state.catProduct.forEach(element => {
            this.catView.push(
                <div className="col-md-3 mb-3" key={element.id}>
                    <ItemCard cardItem={element}></ItemCard>
                </div>
            );
        })

        return (
            <section>
                <div>
                    <div className="deal24 d-md-none d-lg-none d-xl-none"> 
                        Sales end in… 
                        <Link className="buy-button" to="/deals">BUY NOW</Link>
                    </div>
                    <img className="img-fluid large-cover" src={require("../assets/images/deals/deal-cover.png")} />
                    <img className="img-fluid small-cover" src={require("../assets/images/deals/mobile-deal-cover.png")} />
                </div>
                <div className="container mt-5 mb-5">
                    <div className="row ">
                        <div className="col-lg-6 col-sm-12 col-xs-12 d-flex justify-content-center">
                            <a href="#dog"><img className="img-fluid" src={require("../assets/images/dog-deals-cover.png")} alt="dog" /></a>
                        </div>
                        <div className="col-lg-6 col-sm-12 col-xs-12 d-flex justify-content-center">
                            <a href="#cat"><img className="img-fluid" src={require("../assets/images/cat-deals-cover.png")} alt="cat" /></a>
                        </div>
                    </div>
                    <div id="dog" className="my-3">
                        <div className="row py-3">
                            <div className="col-lg-12 d-flex justify-content-center">
                                <img className="img-fluid" src={require("../assets/images/deals/shop-for-dog.png")} alt="dog shop" />
                            </div>
                        </div>
                        <div className="row py-3">
                            {this.dogView}
                        </div>
                    </div>
                    <div id="cat" className="my-3">
                        <div className="row py-3">
                            <div className="col-lg-12 d-flex justify-content-center">
                                <img className="img-fluid" src={require("../assets/images/deals/shop-for-cat.png")} alt="cat shop" />
                            </div>
                        </div>
                        <div className="row py-3">
                            {this.catView}
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}
