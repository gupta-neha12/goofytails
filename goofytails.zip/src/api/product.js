import React from 'react'

const product = () => {
    return ({
        productId: 1,
        name: 'Arden Grange Puppy Junior Chicken and Rice Dog Food',
        description: [
            "Most suitable for small and medium breed puppies (2-9 months)",
            "Small kibble size, rich in protein, easily digestible",
            "Hypoallergenic: Free from wheat, beef, Soya and dairy products",
            "No genetically modified ingredients",
            "Highly digestive recipe formulated to meet the extra energy requirements of growing puppies.",
            "Growth & development diet for fussy eaters"
        ],
        price: 13500,
        stock: 'Out OF Stock',
        quantity: 1,
        pincode: '',
        weight: [2, 6, 12],
        image: require('./../assets/images/product/product-image-1.png'),
        images: [
            require('./../assets/images/product/product-image-1.png'),
            require('./../assets/images/product/product-image-2.png'),
            require('./../assets/images/product/product-image-3.png'),
            require('./../assets/images/product/product-image-4.png'),
            require('./../assets/images/product/product-image-1.png'),
            require('./../assets/images/product/product-image-2.png'),
            require('./../assets/images/product/product-image-3.png'),
            require('./../assets/images/product/product-image-4.png')
        ],
        additionalInfo: [
            { key: 'Brand', value: 'Arden Grang' },
            { key: 'Breed Size', value: 'Small Breed Dogs ( <10kgs), Medium Breed Dogs (10-20kgs), Large Breed Dogs (20-40kgs)' },
            { key: 'Food Form', value: 'Dry' },
            { key: 'Life Style', value: 'Puppy' },
            { key: 'Special Diet', value: 'Regular' }
        ],
        review: [],
        descriptionBlock: (
            <div>
                <div>Arden Grange Puppy Junior rice in fresh chicken is a complete, super-premium pet food for small and medium breed puppies and adolescent dogs. It has been formulated with the optimal balance of vitamins and minerals to encourage steady, healthy growth and development. A generous helping of fresh chicken is included to provide a delicious and easily digestible source of protein</div>
                <p><strong>Nutritional Information:</strong></p>
                <ul>
                    <li>Small size – ideal for small and medium breeds</li>
                    <li>Extremely palatable – perfect for fussy eaters</li>
                    <li>Highly digestible ingredients – less waste</li>
                    <li>High proportion of fresh chicken – meat protein of a very high biological value</li>
                    <li>Added antioxidants and nucleotides – to support the developing immune system and dental hygiene</li>
                    <li>Calories per 100 gm: 400</li>
                </ul>
                <p><b>Analytical Constituents:</b>&nbsp;Crude Protein 29%, Fat Content 18%, Crude Ash 7%, Crude Fibres 2.5%, Calcium 1.3%, Phosphorous 0.85%, Omega-3 0.78%, Omega-6 3.55%.</p>
                <p><b>Composition:</b>&nbsp;Composition: Chicken, (Fresh chicken 18%, chicken meat meal 18%), rice, maize, refined chicken oil, whole dried egg, beet pulp, fish meal, chicken digest, whole linseed, krill, yeast, minerals, prebiotic FOS, prebiotic MOS, yucca extract, glucosamine, MSM, chondroitin, cranberries, nucleotides.</p>
                <p>
                    <b>Nutritional Additives&nbsp;(per kg)</b><br /><b>Vitamins:</b>&nbsp;Vitamin A 21,000 IU, Vitamin D3 1575 IU, Vitamin E 280 IU.
                </p>
                <p><b>Trace Elements:</b>&nbsp;Zinc chelate of amino acid hydrate 583 mg, Copper chelate of amino acid hydrate 117 mg, Manganese chelate of amino acid hydrate 78 mg, Calcium iodate anhydrous 2.8 mg, Selenised Yeast (inactivated) 76 mg, Antioxidant (rosemary extract)</p>
                <p><strong>Feeding Guide</strong></p>
                <p>The breed, age, activity level and temperament of your dog will influence the amount of food required. The quantities shown in the chart below are for guidance only. Always ensure fresh, clean drinking water is available.</p>
            </div>
        )
    });
}

export default product;

